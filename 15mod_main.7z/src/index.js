import './style.css';
import React from "react";
import ReactDOM from "react-dom";
import AddComment from './AddComment';

function getDate() {
    let data    = new Date(),
        year    = data.getFullYear(),
        month   = data.getMonth(),
        date    = data.getDate(),
        hour    = data.getHours(),
        minute  = data.getMinutes(),
        second  = data.getSeconds();
        (function formateDate() {
            if(month < 10) month   = '0' + month;
            if(date < 10) date     = '0' + date;
            if(minute < 10) minute = '0' + minute;
            if(second < 10) second = '0' + second;
        }())
        return `${date}.${month}.${year}, ${hour}:${minute}:${second}`;
}
class WidgetComment extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            comments:[],
            textComent: '',
            name: ''
            }
    }
    componentDidMount(){
        if(localStorage.getItem('state')){
            const localStorageRef = localStorage.getItem('state');
            this.setState({comments: JSON.parse(localStorageRef)});
        }
    }

    addComments () {
        const name = this.state.name;
        const coment = this.state.textComent;
        if(coment !== '' && name !== '') {
            const block = this.state.comments;
            block.push({
                id: this.state.comments.length ? this.state.comments.reduce((p, c) => p.id > c.id ? p : c).id + 1 : 1,
                date: getDate(),
                name: this.state.name,
                comment: this.state.textComent
            })
        this.setState({block, textComent: '', name: ''}, () => localStorage.setItem('state', JSON.stringify(this.state.comments)))
        }else {
            alert(`Пустой коментарий отправить не возможно! Заполните поля!`)
        }
    }

    removeComments = id => {this.setState({
        comments: this.state.comments.filter(el => el.id !== id) 
    }, () => localStorage.setItem('state', JSON.stringify(this.state.comments)))}

    render() {
        return(
            <div className="main-block container">
                <textarea className="write-comment" 
                    value={this.state.textComent}
                    onChange={ev => {
                        this.setState({textComent: ev.target.value})
                    }}>
                </textarea>
                <div className="contain-button">
                    <input className="input" name="name"
                    maxLength="20" value={this.state.name} onChange={e => {
                        this.setState({name: e.target.value})
                    }}
                    placeholder="Укажите имя автора:" required/>
                    <button className="add-comment" onClick={this.addComments.bind(this)}>Отправить комментарий</button>
                </div>
                {this.state.comments.map(el => {
                    return <AddComment 
                            key={el.id}
                            comments={el}
                            date={el.date}
                            name={el.name}
                            comment={el.comment}
                            removeComments={this.removeComments}
                        />
                    })
                }
            </div>
        )
    }
}
ReactDOM.render(
    <WidgetComment />,
    document.querySelector('.main-block'),
)