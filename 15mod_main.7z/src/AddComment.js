import React from "react";

const AddComment = (props) => {
    return <div className="block-comment">
            <span className="comment">{props.comment}</span>
            <div className="content-comment">
                <span className="autor">Автор: {props.name}</span>
                <span className="date-comment">Дата-время: {props.date}</span>   
                <button className="delete-comment" onClick={() => props.removeComments(props.comments.id)}>Удалить</button>
            </div> 
        </div>
}
export default AddComment;